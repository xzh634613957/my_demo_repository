def receive():
    return "这是一条来自10086的短信"